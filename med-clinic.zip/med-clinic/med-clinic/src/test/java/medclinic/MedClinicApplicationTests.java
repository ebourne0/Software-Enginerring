package medclinic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedClinicApplicationTests {

	@Test
	void contextLoads() {
	}

}
